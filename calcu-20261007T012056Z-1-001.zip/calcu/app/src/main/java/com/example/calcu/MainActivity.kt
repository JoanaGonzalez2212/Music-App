package com.example.calcu

import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.widget.Button

class MainActivity : AppCompatActivity() {
    private var agregaOperacion = false
    private var agregaDecimal = true
    private var mostrarResultado = false
    private lateinit var vistaTxt: TextView
    private lateinit var resultadoTxt: TextView


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        vistaTxt = findViewById(R.id.txtvista)
        resultadoTxt = findViewById(R.id.txtResultado)
    }

    //funcion para el contenido
    fun BorraTodo(view: View) {
        vistaTxt.text = ""
        resultadoTxt.text = ""
    }

    //funcion para borrar solo un espacio
    fun BorrarEspacio(view: View) {
        val cadena = vistaTxt.length()
        if (cadena > 0)
            vistaTxt.text = vistaTxt.text.subSequence(0, cadena - 1)
    }

    //funcion que llama a los numeros
    fun ejecutaNumeros(view: View) {
        if (view is Button) {
            if (mostrarResultado) {
                vistaTxt.text = ""
                mostrarResultado = false
            }
            if (view.text == ".") {
                if (agregaDecimal) {
                    vistaTxt.append(view.text)
                    agregaDecimal = false
                }
            } else {
                vistaTxt.append(view.text)
                agregaOperacion = true
            }
        }
    }

    fun ejecutaOperacion(view: View) {
        if (view is Button && agregaOperacion)
            vistaTxt.append(view.text)
        agregaOperacion = false
        agregaDecimal = true
    }
    fun igualarAccion(view: View)
    {

        resultadoTxt.text = calculaResultado()
    }


    fun calculaResultado(): String {
        val digitaOperacion = digitaOperacion()
        if(digitaOperacion.isEmpty())
            return ""

        val multidivision = multidivisionCalcular(lista=digitaOperacion())
        if (multidivision.isEmpty())
            return ""
        val resultado = sumayresta(lista = multidivision)
        return resultado.toString()

        return ""
    }


    private fun multidivisionCalcular(lista: MutableList<Any>): MutableList<Any>{
        var lista = lista

        while(lista.contains('x')||lista.contains('/')){
            lista=calculaOperacion(lista)
        }
        return lista
    }

    fun digitaOperacion(): MutableList<Any>{
        var lista = mutableListOf<Any>()
        var digitaActual = ""

        for (caracter in vistaTxt.text){
            if (caracter.isDigit() || caracter == '.')
                digitaActual += caracter
            else{
                lista.add(digitaActual.toFloat())
                digitaActual=""
                lista.add(caracter)
            }
        }
        if(digitaActual != "")
            lista.add(digitaActual.toFloat())
        return lista
    }
    private fun calculaOperacion(lista: MutableList<Any>): MutableList<Any> {
        val nuevaLista = mutableListOf<Any>()
        var iniciaIndice=lista.size

        for (i in lista.indices)
        {
            if (lista[i] is Char &&  i != lista.lastIndex && i < iniciaIndice)
            {
                val operador = lista[i]
                val operadorAnterior = lista[i-1] as Float
                val siguiente= lista [i + 1] as Float
                when(operador)
                {
                    'x'->
                    {
                        nuevaLista.add(operadorAnterior*siguiente)
                        iniciaIndice= i+1
                    }
                    '/'->
                    {
                        nuevaLista.add(operadorAnterior/siguiente)
                        iniciaIndice= i+1
                    }
                    else ->
                    {
                        nuevaLista.add(operadorAnterior)
                        nuevaLista.add(operador)
                    }
                }
            }
            if (i>iniciaIndice)
                nuevaLista.add(lista[i])
        }
        return nuevaLista
    }

    private fun sumayresta(lista: MutableList<Any>):Float
    {
        var result = lista[0] as Float
        for(i in lista.indices)
        {
            if (lista[i] is Char && i != lista.lastIndex)
            {
                val operador = lista[i]
                val siguiete = lista[i+1] as Float

                if (operador == '+')
                {
                    result += siguiete
                }
                if (operador == '-')
                {
                    result -=siguiete
                }
            }
        }
        return result
    }

}




